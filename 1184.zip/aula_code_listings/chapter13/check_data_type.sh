# $1 is the value entered by the user
# $2 is the expected datatype 
check_data_type() {
   case $2 in
      integer)
         echo "$1" | egrep -q '^[0123456789]+$'
         ;;
      network_address)
         echo "$1" | \
            egrep -q \
               '^[0123456789]{1,3}\.[0123456789]{1,3}\.
               [0123456789]{1,3}\.[0123456789]{1,3}$' 
         ;;
      directory)
         test -d "$1"
         ;;
      file)
         test -f "$1"
         ;;
      *)
         # Unsupported datatype, return true
         true
         ;;
   esac
   return $?
}
