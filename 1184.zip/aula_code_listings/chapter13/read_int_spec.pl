#!/usr/bin/perl -w
use strict;

sub read_pipe_file ($) {
   my ($file) = @_;
   my (@ret, $entry);
   open(FILE, $file) or return undef;
   while (my $line = <FILE>) {
      chomp($line);
      next if ($line =~ /^\s*$/); # skip blank lines
      next if ($line =~ /^\s*#/); # skip comments

      # Now retrieve name/values for current line
      $entry = ();
      while ($line =~ s/^\|([^=|]+)=([^|]*)//) {
         $entry->{$1} = $2;
      }
      push @ret, $entry;
   }
   close(FILE);
   return (@ret);
}

foreach my $entry (read_pipe_file '/tmp/test.conf') {
   foreach (keys %{$entry}) {
      print "$_: $entry->{$_}\n";
   }
}
