# Should be named MyLib.pm and be placed in the module search path
package MyLib;

sub read_file ($) {
   my ($file) = @_;
   my %ret;
   open(FILE, $file) or return undef;
   while (my $line = <FILE>) {
      chomp($line);
      next if ($line =~ /^\s*$/); # skip blank lines
      next if ($line =~ /^\s*#/); # skip comments

      # Split into name and value
      my ($name, $value) = split('=', $line, 2);
      next unless ($name and $value);

      # Remove single-quotes
      $value =~ s/^'//;
      $value =~ s/'$//;

      # Store value
      $ret{$name} = $value;
   }
   close(FILE);
   return \%ret;
}

sub read_pipe_file ($) {
   my ($file) = @_;
   my (@ret, $entry);
   open(FILE, $file) or return undef;
   while (my $line = <FILE>) {
      chomp($line);
      next if ($line =~ /^\s*$/); # skip blank lines
      next if ($line =~ /^\s*#/); # skip comments

      # Now retrieve name/values for current line
      $entry = ();
      while ($line =~ s/^\|([^=|]+)=([^|]*)//) {
         $entry->{$1} = $2;
      }
      push @ret, $entry;
   }
   close(FILE);
   return (@ret);
}

sub write_file ($$) {
   my ($file, $data_ref) = @_;
   open(FILE, ">$file") or return 0;
   foreach my $name (keys %{$data_ref}) {
      print FILE "$name='$data_ref->{$name}'\n";
   }
   close(FILE);
   return 1;
}

1;
