#!/bin/bash

CONFIG_IN="/usr/local/etc/config.in"
CONFIG_OUT="/usr/local/var/config.out"

get_value() {
   echo "$1" | sed "s/.*|$2=\([^|]*\).*/\1/"
}

check_value() {
   var="$(get_value "$1" var)"
   default="$(get_value "$1" default)"
   case "$2" in
      *"'"*)
         echo " ** Single quotes (') are not allowed! **"
         ;;
      '')
         if eval [ -z "\"\${$var:-$default}\"" ]; then
            echo " ** Please enter a value (no default available) **"
         else
            eval echo "$var=\"'\${$var:-$default}'\"" >&2
            return 0
         fi
         ;;
      *)
         echo "$var='$2'" >&2
         return 0
         ;;
   esac
   return 1
}

# First, read existing values, if any
source $CONFIG_OUT 2>/dev/null

while read line <&3 ; do
   case "$line" in 
      \#*|"") 
         # Skip comments and blank lines
         continue 
         ;; 
   esac
   # Found a valid line, retrieve data and store parameters
   var="$(get_value "$line" var)"
   default="$(get_value "$line" default)"
   [ -z "$var" ] && continue
   # Now request and store all settings
   while true ; do
      echo "$var: $(get_value "$line" desc)"
      eval echo -n \
         "\"Enter a value for $var [\${$var:-$default}]: \""
      read input
      echo
      check_value "$line" "$input" && break
      echo
   done
done 3<$CONFIG_IN 2>$CONFIG_OUT.$$
mv -f $CONFIG_OUT.$$ $CONFIG_OUT
