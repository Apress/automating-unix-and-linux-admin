sub read_file ($) {
   my ($file) = @_;
   my %ret;
   open(FILE, $file) or return undef;
   while (my $line = <FILE>) {
      chomp($line);
      next if ($line =~ /^\s*$/); # skip blank lines
      next if ($line =~ /^\s*#/); # skip comments

      # Split into name and value
      my ($name, $value) = split('=', $line, 2);
      next unless ($name and $value);

      # Remove single-quotes
      $value =~ s/^'//;
      $value =~ s/'$//;

      # Store value
      $ret{$name} = $value;
   }
   close(FILE);
   return \%ret;
}

