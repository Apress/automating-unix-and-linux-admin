# Abort the program, displaying an error
die() {
   echo "   ERROR: $*" >&2
   exit 1
}

# arg1: full path of configuration file to read
read_conf() {
   if [ -f "$1" ] ; then
      source "$1" || die "Could not source $1"
      echo "   Processed Config: $1"
   fi
   return 0
}

# arg1: full path of local source file
# arg2: full path of local destination file
do_template() {
   local src="$1"
   local dest="$2"
   [ -z "$src" -o -z "$dest" ] && 
      die "do_template called with empty parameter(s) ($*)"

   # Process the template
   sed 's/\\/\\\\\\\\/g; s/"/\\\\"/g;' "$src" | while read line; do
      eval echo "\"$line\"";
   done > "$dest" || die "Could not process template $src"

   echo "   Processed Template: $(basename "$src")"
}

# arg1: full path of local source file
# arg2: hostname of remote system
# arg3: [optional] destination file on remote system
push_file() {
   local src="$1"
   local host="$2"
   local dest="$3"
   [ -z "$src" -o -z "$host" ] && 
      die "push_file called with missing parameter(s) ($*)"

   # Read configuration items from file
   eval `sed -n 's/^__://p' "$src"`

   # Override location if necessary
   [ -n "$dest" ] && LOCATION="$dest"
   
   # Push the file now
   grep -v '^__:' "$src" | ssh -T "root@$host" "cat > $LOCATION" ||
      die "Could not place remote file $LOCATION"

   # Set the permissions, if necessary
   [ -n "$PERMS" ] && ssh "root@$host" "chmod $PERMS $LOCATION" ||
      die "Could not set permissions on remote file $LOCATION"

   # Set the ownership, if necessary
   [ -n "$USERGROUP" ] && ssh "root@$host" \
      "chown $USERGROUP $LOCATION" ||
      die "Could not set permissions on remote file $LOCATION"

   [ -z "$dest" ] && {
      # Only produce output if third arg was not given
      # (third arg is given when pushing scripts to execute)
      echo "   Pushed File: $LOCATION"
   }
}
