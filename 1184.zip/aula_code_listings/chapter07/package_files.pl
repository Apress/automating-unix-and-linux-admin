#!/usr/bin/perl -w
use strict;
use File::Copy;

my $WebRoot = "/var/www/html/sysconfig";
my @Files = (
   "/etc/hosts",
   "/etc/ssh/sshd_config",
   "/etc/resolv.conf"
   );

# First, erase the manifest file
# (so clients cannot update during this build process)
unlink "$WebRoot/manifest.html";

# Create new manifest file (with temporary name)
open (MANIFEST, ">$WebRoot/manifest.new.html") or
   die "Could not create $WebRoot/manifest.new.html: $!\n";

my $ret = 0;
foreach my $file (@Files) {
   # Get information on the file
   my ($mode, $uid, $gid, $size, $checksum);
   unless (
      (undef, undef, $mode, undef, $uid, $gid, undef, $size) =
       stat $file) {
      # There was an error, skip this file
      print STDERR "WARNING: Could not stat $file: $!\n";
      $ret++;
      next;
   }

   # Isolate permissions from mode and convert to octal string
   $mode = sprintf "%04o", $mode & 07777;

   # Turn UID and GID into user/group names
   $uid = getpwuid($uid);
   $gid = getgrgid($gid);

   # Get a checksum for the file
   $checksum = `md5sum "$file"`;
   chomp($checksum);
   # Strip off everything after the first whitespace
   $checksum =~ s/\s+.*$//;

   # Now, copy the file
   unless (copy "$file", "$WebRoot") {
      print STDERR "Could not copy $file to $WebRoot: $!\n";
      $ret++;
      next;
   }

   # Remove the path from the file
   my $basename = $file;
   $basename =~ s/^.*\///;

   # Make sure it is publicly readable
   chmod 0644, "$WebRoot/$basename";

   # Okay, create the manifest entry
   print MANIFEST "<A href=\"$basename\" dest=\"$file\"\n",
      "perms=\"$mode\" user=\"$uid\" group=\"$gid\"\n",
      "size=\"$size\" md5sum=\"$checksum\"></A>\n\n";

   print "Packaged $file\n";
}

close (MANIFEST);

# Now rename the file so clients can update themselves again
move "$WebRoot/manifest.new.html", "$WebRoot/manifest.html" or
   die "Could not create $WebRoot/manifest.html: $!\n";

# Make sure it is publicly readable
chmod 0644, "$WebRoot/manifest.html";

print "Packaging Complete!\n";
exit $ret;
