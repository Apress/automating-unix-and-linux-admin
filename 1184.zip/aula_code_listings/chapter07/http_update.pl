#!/usr/bin/perl -w
use strict;
use File::Copy;

my $URL = "http://configserver.mydomain.com/sysconfig/manifest.html";
my $TempDir = "/usr/local/var/http_update";
my $wget = 'wget -q --recursive --no-host-directories';

unless (-d $TempDir) {
   mkdir $TempDir, 0700 or die
      "Could not create temporary directory $TempDir: $!\n";
}

# Go into our temporary directory
chdir $TempDir or die
   "Could not enter temporary directory $TempDir: $!\n";

# Retrieve the manifest (and other files)
unless (system ("$wget '$URL'") == 0) {
   die "wget could not retrieve $URL\n";
}

chdir "sysconfig" or die
   "Could not enter sysconfig directory: $!\n";

# Load data from manifest file
my ($line, $entryhash, @Entries, $name, $value);
open (MANIFEST, 'manifest.html');
while ($line = <MANIFEST>) {
   chomp($line);
   # First, look for name/value pairs on this line
   while ($line =~ s/^.*?([^\s=]+)="([^"]+)"//) {
      # Found a name/value pair
      $name = $1;
      $value = $2;
      # Add to hash table
      $entryhash->{$name} = $value;
   }
   if ($line =~ /<\/A>/) {
      # Ending an entry, add what we have to the list
      push @Entries, $entryhash;
      $entryhash = undef;
   } 
}
close (MANIFEST);

# Delete manifest file
unlink 'manifest.html';

# Okay, now we have all the information we need in @Entries
# We have one entry per file, and each entry is a hash reference
my $ret = 0;
foreach my $entry (@Entries) {
   my ($uid, $gid, $perms, $checksum);
   my $file = $entry->{'href'};
   print "$file: ";

   # First, make sure the file we received is valid 
   unless ((-s $file) == $entry->{'size'}) {
      print "FAILED!\n";
      print STDERR "Size of $file not correct... Skipping.\n";
      $ret++;
      next;
   }
   print "[Size OK] ";

   # Check the md5sum
   $checksum = `md5sum "$file"`;
   chomp($checksum);
   # Strip off everything after the first whitespace
   $checksum =~ s/\s+.*$//;
   unless ($checksum eq $entry->{'md5sum'}) {
      print "FAILED!\n";
      print STDERR "MD5 checksum of $file failed... Skipping.\n";
      $ret++;
      next;
   }
   print "[MD5 OK] ";

   # Next, set the permissions/ownership on the new file
   unless (defined($uid = getpwnam $entry->{'user'})) {
      print "FAILED!\n";
      print STDERR "Could not lookup user $entry->{'user'}\n";
      $ret++;
      next;
   }
   unless (defined($gid = getgrnam $entry->{'group'})) {
      print "FAILED!\n";
      print STDERR "Could not lookup group $entry->{'group'}\n";
      $ret++;
      next;
   }
   unless (chown $uid, $gid, $file) {
      print "FAILED!\n";
      print STDERR "Could not set user/group to $uid:$gid: $!\n";
      $ret++;
      next;
   }
   $perms = $entry->{'perms'};
   unless (chmod oct($perms), $file) {
      print "FAILED!\n";
      print STDERR "Could not set permissions to $perms: $!\n";
      $ret++;
      next;
   }

   # Now, move the file to its new destination
   unless (move $file, $entry->{'dest'}) {
      print "FAILED!\n";
      print STDERR "Could not move $file to $entry->{'dest'}: $!\n";
      $ret++;
      next;
   }

   print "Done!\n";
}

exit $ret;
