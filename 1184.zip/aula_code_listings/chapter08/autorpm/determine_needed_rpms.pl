#!/usr/bin/perl -w
use strict;

my $GroupFile = "/etc/responsibilities";
my $GroupDir = "/usr/local/etc/groups";
my $RPMDir = "/usr/local/distribution/RedHat/RPMS";

my %AllRPMs;
my %PkgsByGroup;
my %AllGroups;
my %MyGroups;

sub ReadGroup {
   my ($group) = @_;
   my $file;
   my $line;
   my @ret;
   open($file, "$GroupDir/$group") or
      die "Could not open $GroupDir/$group: $!\n";
   while ($line = <$file>) {
      chomp($line);
      $line =~ s/^\s+//;
      $line =~ s/\s+$//;
      if ($line =~ s/^\@\s*(.+)$/$1/) {
         # Including another group
         push @ret, ReadGroup($line);
      } else {
         push @ret, $line;
      }
   }
   close($file);
   return (@ret);
}

# Retrieve list of all RPMs
my $rpm;
foreach $rpm (`rpm -qp --queryformat="%{NAME}\n" $RPMDir/*.rpm`) {
   chomp($rpm);
   $AllRPMs{$rpm}++;
}

# Read in list of group RPMs
my $file;
opendir(GROUPDIR, $GroupDir) or die "Could not access directory $GroupDir: $!\n";
while ($file = readdir(GROUPDIR)) {
   next if $file =~ /^\./;
   foreach $rpm (ReadGroup($file)) {
      $AllGroups{$rpm}++;
      $PkgsByGroup{$file}{$rpm}++;
   }
}
closedir(GROUPDIR);

# Determine the RPMs from the groups we are in
my $group;
open (GROUPS, $GroupFile) or die "Could not open $GroupFile: $!\n";
while ($group = <GROUPS>) {
   chomp($group);
   if ($PkgsByGroup{$group}) {
      foreach $rpm (keys %{$PkgsByGroup{$group}}) {
         $MyGroups{$rpm}++;
      }
   } else {
      print STDERR "WARNING: Unknown group: $group\n";
   }
}
close (GROUPS);

unless (keys %MyGroups) {
   die "No responsibilities defined!\n";
}

# Now, output RPM listing
foreach $rpm (keys %AllRPMs) {
   if ($AllGroups{$rpm}) {
      if ($MyGroups{$rpm}) {
         print "$rpm\n";
      }
   } else {
      print "$rpm\n";
   }
}

