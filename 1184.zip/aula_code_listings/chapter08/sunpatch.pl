#!/usr/bin/perl -w
use strict;

my $PatchDir = "/mnt/patches";

# Determine the current Solaris release
my $Release = `uname -r`;
chomp($Release);

my (%Installed, %Available);

sub StoreEntry ($$) {
   my ($hashref, $id) = @_;
   my $patch = $id;
   my $release = $id;
   $patch =~ s/-\d+$//;
   $release =~ s/^\d+-//;
   if ($hashref->{$patch}) {
      # Already exists... compare releases
      if ($release > $hashref->{$patch}) {
         $hashref->{$patch} = $release;
      }
   } else {
      # Doesn't exist yet
      $hashref->{$patch} = $release;
   }
}

sub InstallPatch {
   my ($patch) = @_;
   my $id = "$patch-$Available{$patch}";
   my $PatchLocation = "$PatchDir/$Release/$id";
   print "   Installing $id...\n";

   # Check for dependencies
   my %deps;
   unless (opendir(PATCHDIR, $PatchLocation)) {
      print STDERR "   Could not open $PatchLocation: $!\n";
      return 1;
   }
   while (my $pkg = readdir(PATCHDIR)) {
      next if ($pkg =~ /^\./);
      next unless (-d "$PatchLocation/$pkg");
      unless (open(PKGINFO, "$PatchLocation/$pkg/pkginfo")) {
         print STDERR
            "   Could not open $PatchLocation/$pkg/pkginfo: $!\n";
         return 1;
      }
      while (my $line = <PKGINFO>) {
         if ($line =~ s/^SUNW_REQUIRES\s*=\s*//) {
            chomp($line);
            if ($line) {
               # Yes, there are dependencies after the = sign
               foreach (split /\s+/, $line) {
                  StoreEntry(\%deps, $_);
               }
            }
         }
      }
      close(PKGINFO);
   }
   closedir(PATCHDIR);

   # See if we have these dependencies
   foreach my $dep (keys %deps) {
      if ($Installed{$dep} and ($Installed{$dep} >= $deps{$dep})) {
         # Patch already installed... good!
      } elsif ($Available{$dep} and 
         ($Available{$dep} >= $deps{$dep})) {
         # Patch available... install
         print "   Installing Dependency: $dep-$Available{$dep}\n";
         unless (InstallPatch($dep) == 0) {
            # Delete failed patch from available list
            delete $Available{$dep};
            return 1;
         }
      } else {
         # Patch not available...
         print STDERR "   Dependency $dep not found\n";
         return 1;
      }
   }

   if (system("patchadd $PatchLocation") == 0) {
      print "   Patch $id Installed!\n";
      StoreEntry(\%Installed, "$id");
      return 0;
   } else {
      print STDERR "   Patch $id FAILED!\n";
      return 1;
   }
}

# Apply is true if first arg is --apply
my $Apply = ($ARGV[0] and ($ARGV[0] eq '--apply'));

# Get list of installed patches
foreach my $line (`patchadd -p`) {
   if ($line =~ /^Patch:\s+([\d-]+)/) {
      StoreEntry(\%Installed, $1);
   }
}

# Get list of available patches
opendir(DIR, "$PatchDir/$Release") or
   die "Could not open directory: $PatchDir/$Release: $!\n";
while (my $entry = readdir(DIR)) {
   next if ($entry =~ /^\./);
   next unless (-d "$PatchDir/$Release/$entry");
   StoreEntry(\%Available, $entry);
}
closedir(DIR);

# Determine which patches need to be installed
my $ret = 0;
foreach my $patch (keys %Available) {
   # Skip if this patch has already failed
   next unless defined($Available{$patch});
   unless ($Installed{$patch} and
      ($Installed{$patch} >= $Available{$patch})) {
      print "Need to install: $patch-$Available{$patch}\n";
      if ($Apply) {
         $ret += InstallPatch($patch);
      } else {
         $ret++;
      }
   }
}
exit $ret;
