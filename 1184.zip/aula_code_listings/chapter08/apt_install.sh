#!/bin/bash

LIST_DIR="/usr/local/etc/pkglists"

list=''
for resp in `cat /etc/responsibilities` ; do
   echo "Installing packages for responsibility $resp... "
   if [ -f "$LIST_DIR/$resp" ] ; then
      for pkg in `cat $LIST_DIR/$resp` ; do
         echo "Installing package $pkg... "
         apt-get --yes install $pkg
         echo "Done with package $pkg."
      done
   fi
   echo "Done with responsibility $resp."
done
