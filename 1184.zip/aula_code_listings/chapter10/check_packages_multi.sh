#!/bin/bash

TMPDIR="$HOME/tmp"

if [ `uname -s` == 'SunOS' ] ; then
   # Solaris
   pkginfo | awk '{print $2}'
elif [ -x /usr/bin/dpkg ] ; then
   # Debian GNU/Linux
   dpkg -l | grep '^ii  ' | awk '{print $2}'
elif [ -x /bin/rpm ] ; then
   # Red Hat Linux (or other RPM-based system)
   rpm -qa --qf '%{name}\n'
fi | sort > $TMPDIR/packages.curr

if [ -r $TMPDIR/packages.last ] ; then
   diff $TMPDIR/packages.last $TMPDIR/packages.curr | \
      sed -n -e 's/^</Removed/p' -e 's/^>/Added/p'  | \
      /usr/local/sbin/report --stdin INFO 'Packages changed'
fi 

mv $TMPDIR/packages.curr $TMPDIR/packages.last
