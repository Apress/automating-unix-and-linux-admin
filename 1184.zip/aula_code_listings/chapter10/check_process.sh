#!/bin/bash

process="/usr/sbin/httpd"
start="service httpd restart"

ps ax | awk '{print $5}' | grep -q "^$process$" || {
   # Apparently not running, so start the process
   eval "$start"
   exit $?
}

exit 0
