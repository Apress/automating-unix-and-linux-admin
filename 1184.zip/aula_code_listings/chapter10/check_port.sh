#!/bin/bash

port="80"
restart="service httpd restart"

netstat -ln | awk '/^tcp/ {print $4}' | grep -q ":$port$" || {
   # Apparently not listening, so run restart command
   eval "$restart"
   exit $?
}

exit 0
