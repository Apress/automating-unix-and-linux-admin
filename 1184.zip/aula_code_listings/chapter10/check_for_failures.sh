#!/bin/bash

# Check for any drive failures
egrep 'I/O error: dev .+, sector' /var/log/messages | \
   /usr/local/sbin/report --stdin CRITICAL 'Drives failure'

# Check for any RAID failures
egrep 'raid.*Disk failure on' /var/log/messages | \
   /usr/local/sbin/report --stdin CRITICAL 'RAID drive failure'
