#!/bin/bash

TMPDIR="$HOME/tmp"

rpm -qa | sort > $TMPDIR/packages.curr

if [ -r $TMPDIR/packages.last ] ; then
   diff $TMPDIR/packages.last $TMPDIR/packages.curr | \
      sed -n -e 's/^</Removed/p' -e 's/^>/Added/p'  | \
      /usr/local/sbin/report --stdin INFO 'Packages changed'
fi 

mv $TMPDIR/packages.curr $TMPDIR/packages.last
