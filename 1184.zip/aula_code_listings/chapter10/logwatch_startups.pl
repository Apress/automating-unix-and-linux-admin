#!/usr/bin/perl -w
# Save as /etc/log.d/scripts/services/startups, and also be sure to create
# /etc/log.d/conf/services/startups.conf as described in the book

use strict;

unless ($ENV{'LOGWATCH_DETAIL_LEVEL'} > 0) {
   # Don't report system boots at lowest detail level
   exit 0;
}

my $startups = 0;
while (my $line = <STDIN>) {
   if ($line eq 'Initializing CPU#0') {
      $startups++;
   }
}

if ($startups > 0) {
   print "System started: $startups Time(s)\n";
}

