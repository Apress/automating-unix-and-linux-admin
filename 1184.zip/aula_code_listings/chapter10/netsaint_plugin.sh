#!/bin/bash

file="$1"

[ -z "$file" ] && {
   echo "No file specified!"
   exit -1   # UNKNOWN
}

if [ -f "$file" ] ; then
   if [ -s "$file" ] ; then
      # Everything is fine
      echo "File $file OK."
      exit 0
   else
      # Warn if the file is empty
      echo "File $file is empty."
      exit 1
   fi
else
   # Error if not a normal file
   echo "$file not a regular file."
   exit 2
fi
