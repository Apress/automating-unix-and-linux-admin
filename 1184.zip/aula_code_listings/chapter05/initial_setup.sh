#!/bin/bash

# First, run 'autorpm' to install additional new software
autorpm auto

# Add 'sysadmin' account if it doesn't exist
grep -q '^sysadmin:' /etc/passwd || {
   useradd sysadmin
}

# Update the sysadmin user's crontab
crontab -u sysadmin ~/setup/sysadmin_crontab

# Disable .rhosts/.shosts authentication on this host
rm -f ~/.rhosts
rm -f ~/.shosts
cp -p /etc/ssh/sshd_config /etc/ssh/sshd_config.new
sed -e 's/RhostsAuthentication.*/RhostsAuthentication no/' \
    -e 's/IgnoreRhosts.*/IgnoreRhosts yes/' \
    /etc/ssh/sshd_config > /etc/ssh/sshd_config.new && \
       mv /etc/ssh/sshd_config.new /etc/ssh/sshd_config

/etc/init.d/sshd restart
