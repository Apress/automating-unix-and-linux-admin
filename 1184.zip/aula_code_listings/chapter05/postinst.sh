#!/bin/sh

# Mount Linux data and binaries via NFS
mount nfsserver:/linux/usr/local /usr/local

# Configure SSH access
mkdir -p ~/.ssh ~/setup
cp /usr/local/etc/global_auth_keys ~/.ssh/authorized_keys
chmod og-rwx ~ ~/.ssh ~/.ssh/*

# Install any RPMs that need to be added
rpm -i /usr/local/src/RPMS/to_install/*.rpm

# Now, run 'autorpm' to install system updates
/usr/local/sbin/autorpm auto

# Generate cfengine key for this client (and copy to server)
mkdir -p /var/cfengine/ppkeys
/usr/local/sbin/cfkey
MY_IP=`ifconfig eth0 | sed -n 's/.*inet addr:\([^ ]*\).*/\1/p'`
cp /var/cfengine/ppkeys/localhost.pub \
   /usr/local/var/cfengine/ppkeys/root-$MY_IP.pub

# Finally, run cfengine to perform all other configuration tasks
/usr/local/sbin/cfagent

# All done (prevent this script from running again)
rm -f /etc/rc.d/rc3.d/S99prepare_system
