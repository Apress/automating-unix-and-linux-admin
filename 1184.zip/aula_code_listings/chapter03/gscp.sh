#!/bin/bash

# Directory containing host file(s)
host_dir='/usr/local/etc/hosts/'

# Check for required arguments
[ $# -gt 2 ] || {
   echo "usage: $0 \"local file(s)\" remote_dir hostgroup ..." >&2
   exit 1
}

# Take the local and remote files off the parameter list
lfile="$1"
shift
rdir="$1"
shift

# Place full paths to each hostfile in $hostfiles
# This loop will loop once for each (remaining) parameter
for hostfile ; do
   if [ -r "$host_dir/$hostfile" ] ; then
      hostfiles="$hostfiles $host_dir/$hostfile"
   else
      echo "INVALID GROUP: $hostfile" >&2
   fi
done

# Make sure we actually have hosts to operate on
[ -n "$hostfiles" ] || exit 1

# Execute the command(s) on each host
for host in `sort $hostfiles | uniq` ; do
   echo "  ** $host **"
   scp -r "$lfile" "$host:$rdir" || {
      echo "ERROR: Could not copy $lfile to $host:$rdir!" >&2
   }
done
