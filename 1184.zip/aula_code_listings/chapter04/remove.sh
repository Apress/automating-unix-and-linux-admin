#!/bin/bash

component_dir="/usr/local/lib/remove_system/"
export data_dir="/usr/local/var/prepare_system/"

echo
echo "Remove System"
echo

echo -n "Enter the system's hostname: "
read -e old_hostname

# Convert all letters to lowercase in $old_hostname
# Be sure to export the variable for use by component scripts
export old_hostname="$(echo $old_hostname | tr 'A-Z' 'a-z')"

# Make sure the hostname *is* already listed
if ! grep -q "^$old_hostname$" "$data_dir/hosts" 2>/dev/null ; then
   echo "Hostname does not exist: $old_hostname" >&2
   exit 1
fi

# Now, execute all component scripts
for script in $component_dir/* ; do
   # Go to next file if this is a directory
   [ -d $script ] && continue
   # Go to next file if this is not executable
   [ -x $script ] || continue
   # Execute this script, execute its output, abort on failure
   eval `$script` || {
      echo "$script returned error" >&2
      exit 1
   }
done

# Remove the hostname from the host list
grep -v "^$old_hostname$" "$data_dir/hosts" > "$data_dir/hosts.new" \
   && mv "$data_dir/hosts.new" "$data_dir/hosts"

echo
echo "System removal complete for $old_hostname"
echo

exit 0
