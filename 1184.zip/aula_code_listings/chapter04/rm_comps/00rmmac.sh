#!/bin/bash

# We must find the MAC address for other removal components
mac_address=`cat "$data_dir/macs" | sed -n \
   "s/^\([0-9a-f:]\+\) $old_hostname$/\1/p"`

# Now, remove this host from the MAC listing
egrep -v "^[0-9a-f:]+ $old_hostname$" \
   "$data_dir/macs" > "$data_dir/macs.new" && \
      mv "$data_dir/macs.new" "$data_dir/macs"
   
# Return the MAC address in case other components need it
echo "export mac_address=$mac_address;"
echo "true;"
exit 0
