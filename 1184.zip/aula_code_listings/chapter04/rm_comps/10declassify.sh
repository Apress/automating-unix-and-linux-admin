#!/bin/bash

host_dir='/usr/local/etc/hosts/'
host_list='/usr/local/etc/all_hosts'

# Remove this host from any groups it might be in
cd $host_dir
for file in * $host_list ; do
   if [ -f $file ] ; then
      grep -v "^$old_hostname$" $file > $file.new && \
         mv $file.new $file
   fi
done

# Indicate success on STDOUT
echo "true;"
exit 0
