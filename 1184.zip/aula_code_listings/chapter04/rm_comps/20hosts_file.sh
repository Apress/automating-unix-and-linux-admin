#!/bin/bash

hosts_file="/etc/hosts"

[ -w "$hosts_file" ] && {
   # First, create the new file with the same permissions
   cp -p "$hosts_file" "$hosts_file.new"
   grep -v "^$ip_address *$old_hostname$" \
      "$hosts_file" > "$hosts_file.new" && \
         mv "$hosts_file.new" "$hosts_file"
}

# Indicate success on STDOUT
echo "true;"
exit 0
