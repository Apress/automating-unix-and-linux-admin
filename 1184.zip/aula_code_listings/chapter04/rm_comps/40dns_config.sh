#!/bin/bash

domain="sample.com"
forward_zone="/usr/local/var/named/sample.com"
rev_zone="/usr/local/var/named/hosts.rev"

# This function requires that the serial number be on
# a line by itself and followed by " ;serial"
increment_serial() {
   [ -w "$1" ] || {
      echo "File $1 doesn't exist or is not writable" >&2
      return
   }
   awk '/;serial/ {print "                  " $1+1 " ;serial"} \
      !/;serial/ {print $0}' "$1" > "$1.tmp" && \
         mv "$1.tmp" "$1"
}

# First, increment the serial numbers
increment_serial "$forward_zone"
increment_serial "$rev_zone"

# Determine reversed-ip 
rev_ip=`echo "$ip_address" | sed \
   's/^\(.*\)\.\(.*\)\.\(.*\)\.\(.*\)$/\4.\3.\2.\1.in-addr.arpa./'`

# Now, remove entries
[ -w "$forward_zone" ] && {
   # First, copy original file, to preserve permissions
   cp -p "$forward_zone" "$forward_zone.new"
   egrep -v "^$old_hostname\.$domain\. +IN A $ip_address" \
      "$forward_zone" > "$forward_zone.new" && \
         mv "$forward_zone.new" "$forward_zone"
}
[ -w "$rev_zone" ] && {
   cp -p "$rev_zone" "$rev_zone.new"
   egrep -v "^$rev_ip +IN PTR $old_hostname\.$domain\." \
      "$rev_zone" > "$rev_zone.new" && \
         mv "$rev_zone.new" "$rev_zone"
}

# Indicate success on STDOUT
echo "true;"
exit 0
