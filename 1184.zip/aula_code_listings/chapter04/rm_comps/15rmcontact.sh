#!/bin/bash

# Now, remove the contact entry for this host
egrep -v "^$old_hostname $mac_address" \
   "$data_dir/contacts" > "$data_dir/contacts.new" && \
      mv "$data_dir/contacts.new" "$data_dir/contacts"

echo "true;"
exit 0
