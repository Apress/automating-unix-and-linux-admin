#!/bin/bash

set -u
component_dir="/usr/local/lib/prepare_system/"
export data_dir="/usr/local/var/prepare_system/"

echo
echo "New System Preparation"
echo

echo -n "Enter the system's hostname: "
read -e new_hostname

# First, convert all letters to lowercase in $new_hostname
# Be sure to export the variable for use by component scripts
export new_hostname="$(echo $new_hostname | tr 'A-Z' 'a-z')"

# Make sure the hostname contains only valid characters
if ! echo "$new_hostname" | egrep -q '^[0-9a-z_-]+$' ; then
   echo "Invalid hostname: $new_hostname" >&2
   exit 1
fi

# Make sure the hostname is not already in use
if grep -q "^$new_hostname$" "$data_dir/hosts" 2>/dev/null ; then
   echo "Hostname already exists: $new_hostname" >&2
   exit 1
fi

# Record the new hostname
echo "$new_hostname" >> "$data_dir/hosts"

# Now, execute all component scripts
for script in $component_dir/* ; do
   # Go to next file if this is a directory
   [ -d $script ] && continue
   # Go to next file if this is not executable
   [ -x $script ] || continue
   # Execute this script, execute its output, abort on failure
   eval `$script` || {
      echo "$script returned error" >&2
      exit 1
   }
done

echo
echo "System preparation complete for $new_hostname"
echo

exit 0
