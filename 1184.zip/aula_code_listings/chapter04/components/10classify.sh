#!/bin/bash

host_dir='/usr/local/etc/hosts/'
group_list='/usr/local/etc/group_list'
host_list='/usr/local/etc/all_hosts'
groups=''

echo >&2
echo "Select one or more groups for this host (Q to quit):" >&2
select group in `cat $group_list` ; do
   if [ -n "$group" ] ; then
      groups="$group $groups"
      echo >&2
      echo "Current List: $groups" >&2
      echo >&2
   else
      break
   fi
done

# Add to group files
for group in $groups ; do
   # Make sure the host is not already in the group
   grep -q "^$new_hostname$" "$host_dir/$group" || {
      echo "$new_hostname" >> "$host_dir/$group"
   }
done

# Always add to "all_hosts" file
echo "$new_hostname" >> "$host_list"

echo >&2
echo "Host $new_hostname added to group(s): $groups" >&2

# Generate output data on STDOUT
echo "export groups='$groups';"
echo "true;"
exit 0
