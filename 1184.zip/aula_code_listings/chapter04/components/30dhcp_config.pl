#!/usr/bin/perl -w
use strict;
my $dhcpd_conf='/usr/local/etc/dhcpd.conf';

# Open up the input and output files
open(IN, "$dhcpd_conf") or die "Could not open $dhcpd_conf: $!\n";
open(OUT, ">$dhcpd_conf.new") or 
   die "Could not open $dhcpd_conf.new: $!\n";

# Now, go through the file, looking for } at beginning of line
my $line;
my $done = 0;
while ($line = <IN>) {
   if ((not $done) and ($line =~ /^\}/)) {
      # Found closing brace at beginning of line
      print OUT "   host $ENV{'new_hostname'} {\n";
      print OUT "      hardware ethernet $ENV{'mac_address'};\n";
      print OUT "      fixed-address $ENV{'ip_address'};\n";
      print OUT "   }\n\n";
      $done = 1;
   }
   # Always print the line out
   print OUT $line;
}
close(IN);
close(OUT);

# Copy the new file over
unless (rename("$dhcpd_conf.new", $dhcpd_conf)) {
   die "Could not replace $dhcpd_conf: $!\n";
}

print STDERR "$ENV{'new_hostname'} added to dhcpd.conf\n";

# Indicate success on STDOUT
print "true;\n";
exit 0
