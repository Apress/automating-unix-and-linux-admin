#!/bin/bash

hosts_file="/etc/hosts"

echo "$ip_address    $new_hostname" >> "$hosts_file"

echo "Added $new_hostname to hosts file" >&2

# Indicate success on STDOUT
echo "true;"
exit 0
