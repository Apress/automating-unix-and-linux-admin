#!/bin/bash

# Args: pattern file
remove_line() {
   cp -p "$2" "$2.new" && \
   egrep -v "$1" "$2" > "$2.new" && \
      mv "$2.new" "$2"
}
export -f remove_line

onlyaction() {
   [ "$action" == "$1" ] || {
      echo 'true;'
      exit 0
   }
}
export -f onlyaction

# Args: message [default_value]
getvalue() {
   value=''
   echo >&2
   while [ -z "$value" ] ; do
      if [ -n "$2" ] ; then
         echo -n "$1 [$2]: " >&2
         read -e value
         if [ -z "$value" ] ; then
            value="$2"
         fi
      else
         echo -n "$1: " >&2
         read -e value
      fi
   done
   echo >&2
   # Return the value on STDOUT
   echo "$value"
}
export -f getvalue

die() {
   echo >&2
   echo "$*" >&2
   echo >&2
   exit 1
}
export -f die

set -a
source /usr/local/etc/usertool.conf

usage() {
   echo "Usage: $0 [username]" 2>/dev/null
   exit 99;
}
[ "$1" == "--help" ] && usage

username="$1"
if [ -z "$username" ] ; then
   username=`getvalue 'Enter the username'`
fi

# Make sure the username contains only valid characters
if ! echo "$username" | egrep -q '^[0-9a-zA-Z_-]+$' ; then
   die "Invalid username: $username"
fi

action=$(basename $0)
if [ "$action" == "adduser" ] ; then
   # Make sure the username is not already in use
   if grep -q "^$username$" "$data_dir/userlist" 2>/dev/null ; then
      die "User already exists: $username"
   fi
   # Record the new username
   echo "$username" >> "$data_dir/userlist"
elif [ "$action" == "deluser" ] ; then
   # Make sure the username exists
   if ! grep -q "^$username$" "$data_dir/userlist" 2>/dev/null ; then
      die "User does not exist: $username"
   fi
else
   die "Unknown action: $action"
fi

# Returns all scripts from a directory
get_scripts() {
   for script in $1/* ; do
      # Go to next file if this is a directory
      [ -d $script ] && continue
      # Go to next file if this is not executable
      [ -x $script ] || continue
      # Good, return this script on STDOUT
      echo $script
   done
}

# Now, execute all data-gathering scripts
for script in `get_scripts $component_dir/data` ; do
   # Execute this script, execute its output, abort on failure
   eval `$script` || die "$script returned error"
done

# Now, execute all modification scripts
for script in `get_scripts $component_dir/mod` ; do
   # Execute this script, execute its output, abort on failure
   $script || die "$script returned error"
done

if [ "$action" == "deluser" ] ; then
   # Remove the username from the user list
   remove_line "^$username$" "$data_dir/userlist"
fi

echo
echo "Action $action for $username has been completed"
echo

exit 0
