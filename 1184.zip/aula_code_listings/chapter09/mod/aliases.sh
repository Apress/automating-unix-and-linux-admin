#!/bin/bash

add_alias() {
   echo "Adding mail alias for $username: $1"
   echo "$1: $username" >> "$alias_file"
}

if [ "$action" == "deluser" ] ; then

   cp -p "$alias_file" "$alias_file.new"
   sed "/: *$username$/d" "$alias_file" > "$alias_file.new" && \
      mv "$alias_file.new" "$alias_file"

else

   # Always add first.last alias
   add_alias `echo "$fullname" | sed 's/ /./g'`
   for alias in $aliases ; do
      add_alias "$alias"
   done

fi
