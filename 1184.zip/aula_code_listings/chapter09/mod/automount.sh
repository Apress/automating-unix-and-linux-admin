#!/bin/bash

[ -n "$automount_file" ] && {
   if [ "$action" == "deluser" ] ; then
      echo "Removing entry from $automount_file..."
      remove_line "^$username" "$automount_file"
   else
      if echo "$homedir" | grep -q ':' ; then
         echo "Adding entry to $automount_file..."
         echo "$username $homedir:$username" >> $automount_file
      fi
   fi
}
