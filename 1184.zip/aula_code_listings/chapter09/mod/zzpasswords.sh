#!/bin/bash

onlyaction 'adduser'

echo
echo "Setting account password..."
if [ -n "$yp_passwd_file" ] ; then
   yppasswd $username
else
   passwd $username
fi

echo
echo "Setting Samba password..."
smbpasswd -a $username

exit 0
