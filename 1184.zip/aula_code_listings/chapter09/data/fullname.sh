#!/bin/bash

onlyaction 'adduser'
fullname=`getvalue "Enter full name for $username"`
echo "fullname='$fullname';"
echo 'true;'
exit 0
