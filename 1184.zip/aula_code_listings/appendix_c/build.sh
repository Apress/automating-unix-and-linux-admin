#!/bin/bash

usage() {
   echo "Usage: $0 <spec-file> <cvs-tag>" >&2
   exit 1
}

die() {
   echo >&2
   echo "ERROR: $*" >&2
   echo >&2
   exit 1
}

getfiles() {
   echo -n "Retrieving $1 from CVS... " >&2
   cvs export -r "$tag" $1 >/dev/null 2>&1 || \
      die "Could not retrieve $1 from CVS"
   echo "Done."
}

dotag() {
   echo -n "Retrieving $1 from CVS... " >&2
   cvs rtag -F -r "$tag" "$2" "$1" >/dev/null 2>&1 || \
      die "Tagging $1 with $2 failed!"
   echo "Done."
}

getinfo() {
   sed -n "s/^$1: *\([^ ][^ ]*\) *$/\1/p" "$spec"
}

[ "$1" == "--help" ] && usage
[ $# -lt 2 ] && usage
spec="$PWD/$1"
tag="$2"
[ -r "$spec" ] || die "Could not access SPEC file"

# Generate build directory structure
topdir="$(rpm --eval '%{_topdir}')"
mkdir -p $topdir/{BUILD,RPMS,SOURCES,SPECS,SRPMS}

# Get name and version from the SPEC file
name="$(getinfo Name)"
version="$(getinfo Version)"

# Retrieve last release and increment by one
release="$(getinfo Release)"
release=$[$release+1]
sed "s/^Release:.*$/Release: $release/" "$spec" >> "$spec.new" && \
   mv "$spec.new" "$spec"

# Retrieve files from CVS
cd "$topdir/SOURCES"
rm -rf "$name"-*
mkdir "$name-$version"
cd "$name-$version"
for entry in `sed -n 's/^#CVS=//p' "$spec"` ; do
   getfiles "$entry"
   [ -e "$entry" ] || die "Failed to retrieve $entry from CVS!"
done || die "Could not retrieve all entries from CVS"

# Next, build the tar file
echo -n "Building $name-$version.tar.gz... "
cd ..
tar -czpf "$name-$version.tar.gz" "$name-$version" || \
   die "Failed to create tar file!"
rm -rf "$name-$version"
echo "Done."

# Now, build the package
rpm -ba "$spec" || die "Failed to build package $name"

# Tag the code in CVS
newtag="RPM-$(echo "$name-$version" | sed 's/\./-/g')-$release"
for entry in `sed -n 's/^#CVS=//p' "$spec"` ; do
   dotag "$entry" "$newtag"
done
