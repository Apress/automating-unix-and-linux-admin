#!/bin/bash

# Drive or directory to clean up
prune="/mnt/backup"

# The maximum used space allowed on the drive (percent)
cutoff="80"

# Removes one increment from each rdiff-backup repository until the 
# drive falls below the specified cutoff
until df "$prune" | awk -v "cutoff=$cutoff" '/^\// {
      gsub(/%$/, "", $5);
      if ($5 > cutoff)
         exit 1
      }' ; do
   # Too full, clean out some old data
   # First, find and store rdiff-backup repositories
   [ -z "$DIRS" ] && {
      for dir in `find $prune -name rdiff-backup-data -type d` ; do
         DIRS="$DIRS $(echo "$dir" | sed 's/\/rdiff-backup-data//')"
      done
   }
   # Now, delete the oldest increment
   for dir in $DIRS ; do
      del=`rdiff-backup -l "$dir" | sed -n \
        's/^ *increments\.\(....-..-.....:..:..-..:..\)\.dir.*/\1/p' \
        | head -n2 | tail -n1`
      echo >&2
      echo "Cleaning $dir..." >&2
      rdiff-backup --remove-older-than "$del" "$dir" >&2 || {
         echo "Only one increment left for $dir (skipping)" >&2
         DIRS=`echo "$DIRS" | sed "s= *$dir *=="`
      }
   done
   # Prevent an infinite loop from occurring
   [ -z "$DIRS" ] && {
      echo >&2
      echo "No rdiff-backup data directories left to prune!" >&2
      exit 1
   }
done

exit 0
