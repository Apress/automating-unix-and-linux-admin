#!/bin/bash

# Where to place backup log files
LOG_DIR="/usr/local/var/backup_logs"

# Which directories to include in backup
DIRS="home"

# Which output file or tape device to use
DEV="/dev/st0"

today=$(date +%a)
cd /
case $today in
   Mon)
      # Full backup
      tar cvpf $DEV $DIRS
      mt -f $DEV rewind
      mt -f $DEV offline
      ;;
   Tue|Wed|Thu|Fri) 
      # Partial backup
      tar cvpf $DEV -N "$(date -d '1 day ago')" $DIRS
      mt -f $DEV rewind
      mt -f $DEV offline
      ;;
   *)
      # Weekend, do nothing
      ;;
esac > "$LOG_DIR/$today"

