#!/bin/bash

BACKUP_SERVER="backup@backup.mydomain.com"
BACKUP_DIR="/usr/local/backup"
DIRS="/etc /var /usr/local /home"

yesterday=`date +%a -d yesterday`
shorthost=`hostname | sed 's/\..*$//'`
archive_dir="$BACKUP_DIR/$shorthost/$yesterday"

# Clean out existing archive directory (from last week)
mkdir -p /root/.emptydir
rsync --delete -a /root/.emptydir/ "$BACKUP_SERVER:$archive_dir/"
rmdir /root/.emptydir

rsync -a --force --ignore-errors --delete \
   --backup --backup-dir=$archive_dir \
   $DIRS "$BACKUP_SERVER:$BACKUP_DIR/$shorthost/current"

