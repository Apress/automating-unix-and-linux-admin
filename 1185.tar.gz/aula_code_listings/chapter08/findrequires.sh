#!/bin/bash

for installed in "$@" ; do
   for require in `rpm -q --requires "$installed"` ; do
      pkg=`rpm -q --whatprovides "$require" 2>/dev/null`
      if [[ $pkg != "no package provides "* ]] ; then
         echo "$pkg"
      fi
   done
done | sort | uniq
