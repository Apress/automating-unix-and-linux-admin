#!/bin/bash

BUNDLE_DIR="/usr/local/packages/bundles"

list=''
for resp in `cat /etc/responsibilities` ; do
   if [ -d "$BUNDLE_DIR/$resp" ] ; then
      echo "Installing bundle $resp... "
      for pkg in "$BUNDLE_DIR/$resp/"* ; do
         name=`rpm -q --queryformat '%{name}' -p $pkg`
         installed=`rpm -q "$name" >/dev/null`
         if [ $? -eq 0 ] ; then
            # Is instaled, see if it is a different version
            if [ "$installed" != "$(rpm -q -p $pkg)" ] ; then
               # Different versions... assume an upgrade
               list="$list $pkg"
            fi
         else
            # Not installed
            list="$list $pkg"
         fi
      done
      [ -n "$list" ] && rpm -Uvh $list
      echo "Done."
   fi
done
