#!/bin/bash

BUNDLE_DIR="/usr/local/packages/bundles"

list=''
for resp in `cat /etc/responsibilities` ; do
   if [ -d "$BUNDLE_DIR/$resp" ] ; then
      echo "Installing bundle $resp... "
      for pkg in "$BUNDLE_DIR/$resp/"*.rpm ; do
         name=`rpm -q --queryformat '%{name}' -p $pkg`
         if ! rpm -q "$name" >/dev/null ; then
            list="$list $pkg"
         fi
      done
      [ -n "$list" ] && rpm -ivh $list
      # Now, use the -F option to upgrade any packages as necessary
      rpm -Fvh "$BUNDLE_DIR/$resp/"*.rpm
      echo "Done."
   fi
done
