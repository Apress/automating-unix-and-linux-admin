Thank you for your interest in Automating UNIX and Linux Administration.  This
book was published in September 2003 by Apress and written by Kirk Bauer.  You
can submit corrections on the Apress website (www.apress.com) as well as ask
questions in the forums also found there.  You can also contact the author
directly at: kirk@kaybee.org.

Don't forget: all of the example scripts assume the following binaries are
located in the following locations.  You will need to change the first line
of each applicable script if the locations in your environment differ:
   /usr/bin/perl
   /bin/bash

All files are in the UNIX file format.  If you are viewing these in Windows,
you must either convert them or use a real editor like Vim (www.vim.org) or
Emacs.

Here is a summary of the program listings provided in this archive.  The
easiest way to find the code that you are looking for is to scan backwards from
the code listing in the book until you find a section heading.  Then, search
for the section number or title in this file.  

Note that program listings consisting of 10 lines or less are generally not
included.  But, in several chapters, there are a bunch of small code listings
that make up a single script.  These are included as one big script in this
archive.

Chapter 2: Using SSH to Securely Automate System Administration
   2.12 Using SSH for Common Accounts (should be 2.6)
      2.12.1 Preparing for Common Accounts
         Perl Script: chapter02/accounts.pl
      2.12.2 Monitoring the Common Accounts
         Perl Script: chapter02/sshreport.pl

Chapter 3: Creatin Login and Shell Scripts
   3.1 Tailoring the Command Prompt
      3.1.2 Using Colored Prompts
         Bash Script: chapter03/example_bashrc1
         Bash Script: chapter03/example_bashrc2
   3.2 Using Tab Completion
      3.2.3 Using Custom Completion Functions
         Bash Script: chapter03/umount_function.sh
   3.4 Creating Commands That Affect Multiple Systems
      3.4.1 Simple Multi-SSH
         Bash Script: chapter03/mssh.sh
      3.4.2 Group-Based Multi-SSH
         3.4.2.2 Executing Commands
            Bash Script: chapter03/gssh.sh
         3.4.2.3 Copying Files
            Bash Script: chapter03/gscp.sh
   3.5 Distributing Your Login Scripts
      3.5.2 Distributing Login Scripts
         3.5.2.2 Creating the Distribution Script
            Bash Script: chapter03/distrib.sh

Chapter 4: Pre-Installation: Network Preparation and Management
   4.3 Using Locking to Prevent Conflicts
      Bash Script: chapter04/locking.example
   4.4 Base Pre-Installation Script
      Bash Script: chapter04/prepare.sh
   4.5 The Pre-Installation Component Scripts
      4.5.1 Requesting the MAC Address
         Bash Script: chapter04/components/00getmac.sh
      4.5.2 Allocating an IP
         Bash Script: chapter04/components/05allocate_ip.sh
      4.5.3 Classifying the System
         Bash Script: chapter04/components/10classify.sh
      4.5.4 Gathering Contact Information
         Bash Script: chapter04/components/15getcontact.sh
      4.5.5 Adding to the /etc/hosts File
         Bash Script: chapter04/components/20hosts_file.sh
      4.5.6 Configuring a DHCP Server
         Perl Script: chapter04/components/30dhcp_config.pl
      4.5.7 Updating your DNS Configuration
         Bash Script: chapter04/components/40dns_config.sh
   4.7 Removing Machines
      Bash Script: chapter04/remove.sh
      4.7.1 Removing MAC Addresses
         Bash Script: chapter04/rm_comps/00rmmac.sh
      4.7.2 Reclaiming IP
         Bash Script: chapter04/rm_comps/05take_ip.sh
      4.7.3 Declassifying a System
         Bash Script: chapter04/rm_comps/10declassify.sh
      4.7.4 Removing Contact Entry
         Bash Script: chapter04/rm_comps/15rmcontact.sh
      4.7.5 Modifying Hosts File
         Bash Script: chapter04/rm_comps/20hosts_file.sh
      4.7.6 Configuring DHCP
         Perl Script: chapter04/rm_comps/30dhcp_config.pl
      4.7.7 Updating your DNS Configuration
         Bash Script: chapter04/rm_comps/40dns_config.sh
         
Chapter 5: Automating and Customizing Installation
   5.3 Preparing for Automated Administration
      5.3.1 Remotely Configuring a New System
         5.3.1.2 Transferring Data
            Bash Script: prepare_system.sh
         5.3.1.3 Configuring the System
            Bash Script: initial_setup.sh
      5.3.2 New Systems That Configure Themselves
         5.3.2.2 Creating the Automatic Preparation Script
            Bash Script: postinst.sh

Chapter 6: System Configuration
   6.3 Custom Configuration Approach
     6.3.3 Presenting the Configuration Script
         6.3.3.1 The config_all_systems Script
            Bash Script: chapter06/config_all_systems.sh
         6.3.3.2 The configure_system Functions
            Bash Script: chapter06/functions.sh
         6.3.3.3 The configure_system Script
            Bash Script: chapter06/configure_system.sh
   6.4 Configuring Systems with GNU cfengine
      6.4.2 Basic Setup      
         6.4.2.3 Creating Configuration Files
            6.4.2.3.2 Basic update.conf
               Cfengine Config File: chapter06/update.conf
            6.4.2.3.3 Framework for cfagent.conf
               Cfengine Config File: chapter06/cfagent.conf

Chapter 7: Sharing Data Between Systems
   7.7 Sharing Data with cfengine
      7.7.1 Distributing Files
         Cfengine Config File: chapter07/cfagent-distrib.conf
      7.7.2 Managing NFS Mounts
         Cfengine Config File: chapter07/cfagent-nfs.conf
   7.8 Synchronizing Data with rsync
      7.8.4 Example rsync Usage
         7.8.4.2 Pulling /usr/local
            Bash Script: chapter07/pull_usr_local.sh
   7.10 HTTP/FTP
      7.10.2 Simple Example: Transferring System Configuration
         Bash Script: chapter07/lftpget.sh
      7.10.3 Advanced Example: Transferring System Configuration
         7.10.3.1 Setting up the Server
            Perl Script: chapter07/package_files.pl
         7.10.3.2 The Client Retrieval Script
            Perl Script: chapter07/http_update.pl
         7.10.3.3 Being Aware of Security Concerns
            7.10.3.3.1 Adding Access Control
               Apache Configuration Directive: chapter07/httpd.conf

Chapter 8: Packages and Patches
   8.4 Updating Systems with Patches
      8.4.1 Understanding and Applying Solaris Patches
         8.4.1.4 The Automatic Patching Script
            Perl Script: chapter08/sunpatch.pl
      8.4.2 Custom Patches
         8.4.2.2 Example patch
            Bash Script: chapter08/check
            Bash Script: chapter08/apply
            Bash Script: chapter08/remove
            Bash Script: chapter08/verify
         8.4.2.4 The mypatch Script
            Bash Script: chapter08/mypatch
   8.5 Understanding and Installing Packages
      8.5.1 Red Hat Package Manager (RPM)
         8.5.1.3 Simple Automation
            8.5.1.3.1 Package Bundles
               8.5.1.3.1.1 Creating Bundles
                  Bash Script: chapter08/findrequires.sh
               8.5.1.3.1.2 Installing Bundles
                  Bash Script: chapter08/install_bundles.sh
                  Bash Script: chapter08/install_bundles2.sh
      8.5.2 Debian Packages
         8.5.2.3 Advanced Packaging Tool
            Bash Script: chapter08/apt_install.sh
   8.6 Automatic Package Installations with AutoRPM
      8.6.4 Example Configuration Files
         8.6.4.1 Simple System Upgrades
            AutoRPM Configuration: chapter08/autorpm/autorpm.conf-simple
         8.6.4.2 Caching Updates Locally
            AutoRPM Configuration: chapter08/autorpm/autorpm.conf-caching
         8.6.4.3 Updating Systems from Previously-Downloaded Package Cache
            AutoRPM Configuration: chapter08/autorpm/autorpm.conf-apply_cached
         8.6.4.4 Precise Package Installation
            AutoRPM Configuration: chapter08/autorpm/autorpm.conf-exact
         8.6.4.5 Advanced Uses
            8.6.4.5.1 Install Only Needed RPMs
               Perl Script: chapter08/autorpm/determine_needed_rpms.pl
               
Chapter 9: System Maintenance and Changes
   9.2 Managing Accounts
      9.2.2 Laying Out the Account Management Configuration File
         Example Configuration File: chapter09/usertool.conf
      9.2.3 Account Management Helper Functions
      9.2.4 Account Management Main Script
         Bash Script: chapter09/usertool.sh
      9.2.5 Account Management Data Components
         9.2.5.1 Allocating UID/GID
            Perl Script: chapter09/data/getuid.pl
         9.2.5.2 Requesting a Full Username
            Bash Script: chapter09/data/fullname.sh
         9.2.5.3 Selecting a Shell
            Bash Script: chapter09/data/shell.sh
         9.2.5.4 Allocating Extra Groups
            Bash Script: chapter09/data/extragroups.sh
         9.2.5.5 Determining the Home Directory
            Bash Script: chapter09/data/homedir.sh
         9.2.5.6 Choosing Mail Aliases
            Bash Script: chapter09/data/aliases.sh
      9.2.6 The Modification Components
         9.2.6.1 Basic Account Setup Script
            Bash Script: chapter09/mod/basic.sh
         9.2.6.2 The Extra Groups Script
            Bash Script: chapter09/mod/extragroups.sh
         9.2.6.3 Adding and Removing from Automount Files
            Bash Script: chapter09/mod/automount.sh
         9.2.6.4 The NIS Update Script
            Bash Script: chapter09/mod/zupdate.sh
         9.2.6.5 The Home Directory Creation Script
            Bash Script: chapter09/mod/homedir.sh
         9.2.6.6 The Mail Aliases Script
            Bash Script: chapter09/mod/aliases.sh
         9.2.6.7 Setting the Passwords
            Bash Script: chapter09/mod/zzpasswords.sh
      9.2.7 Deleted User Cleanup            
         Bash Script: chapter09/full-user-delete.sh 
   9.4 Removing Files
      9.4.1 Custom Drive Cleaning
         9.4.1.2 Cleaning Home Directories
            Bash Script: chapter09/filecheck.sh

Chapter 10: System Monitoring
   10.1 General System Monitoring
      10.1.1 Creating a General Reporting Facility
         Perl Script: chapter10/report.pl
      10.1.3 Watching Available Disk Space
         Bash Script: chapter10/check_drives.sh
      10.1.4 Monitoring System Services
         Example Configuration File: chapter10/services/services.conf
         Bash Script: chapter10/services/services.sh
         Bash Script: chapter10/services/web.sh
      10.1.5 Watching for Package Changes
         Bash Script: chapter10/check_packages.sh
         Bash Script: chapter10/check_packages_multi.sh
      10.1.6 Drive Failures
         Bash Script: chapter10/check_for_failures.sh
   10.2 Monitoring System Logs
      10.2.1 Log Monitoring with Logwatch
         10.2.1.4 Running Logwatch on a Log Host
            Bash Script: chapter10/logwatch_all.sh
         10.2.1.5 Writing Your Own Filter
            10.2.1.5.2 Creating a New Service
               Bash Script: logwatch_example.sh
            10.2.1.5.3 Simple Example Service Filter
               Perl Script: logwatch_startups.pl
   10.3 Monitoring Network Services
      10.3.1 Custom Monitoring and Automatic Repairs
         10.3.1.1 Checking for a Process
            Bash Script: chapter10/check_process.sh
         10.3.1.2 Checking a Port
            Bash Script: chapter10/check_port.sh
         10.3.1.3 Checking a Web Server
            Bash Script: chapter10/check_apache.sh
      10.3.2 NetSaint (a.k.a. Nagios)
         10.3.2.2 NetSaint Configuration
            10.3.2.2.2 Command Declarations
               10.3.2.2.2.6 Service Event Handler
                  Bash Script: chapter10/restart-httpd.sh
         10.3.2.3 Writing Your Own Plugins
            Bash Script: chapter10/netsaint_plugin.sh
      10.3.3 Mon
         10.3.3.4 Real-world Example
            Example Configuration File: chapter10/mon.conf
         10.3.3.5 Custom Monitoring Script
            Bash Script: chapter10/mon-custom.sh
               
Chapter 11: Improving System Security
   10.2 Configuring System-Level Firewalls
      10.2.2 Firewall Configuration Script
         Bash Script: chapter11/firewall-setup
      11.2.3 Groups of Systems
         Bash Script (optional add-on for firewall-setup): chapter11/groups

Chapter 12: Backing Up and Restoring Data
   12.3 Using rsync to Back Up Data
      10.3.2 Incremental Backups
         Bash Script: chapter12/incremental.sh
   12.4 Backup Up Data with rdiff-backup
      10.4.2 Removing Old Backup Data
         Bash Script: chapter12/rdiff-remove.sh
   12.5 Tape Backups With tar
      12.5.2 Incremental Backups
         Bash Script: chapter12/tar_incremental.sh
   
Chapter 13: User Interfaces
   13.2 Creating the Underlying Scripts Working Scripts
      Bash Script: chapter13/add_new_user.sh
   13.3 Executing Commands as root
      13.3.1 Executing Commands with setuid Wrapper
         C Program: chapter13/wrapper.c
   13.4 Designing and Using Common Data Files
      13.4.1 Common File Format for Storing Settings
         13.4.1.3 Reading in Perl
            Perl Program: chapter13/read_name_value.pl
      13.4.2 Designing Interface Specifications
         13.4.2.2 Reading in Perl
            Perl Program: chapter13/read_int_spec.pl
   13.5 Text-based Interface
      13.5.1 Menu Interface
         Shell Script: chapter13/menu.sh
      13.5.2 Configuring Your Text-Based Interface
         13.5.2.2 The Configuration Script
            Shell Script: chapter13/config.sh
         13.5.2.4 Extended Data Checking
            Shell Script: chapter13/extended_check_value.sh
   13.6 Creating a Web-Based Interface
      13.6.2 Introduction to Mason
         13.6.2.3 Expanded Examples
            Mason HTML File: chapter13/mason/getinfo.mhtml
            Mason HTML File: chapter13/mason/showinfo.mhtml
            Mason Component File: chapter13/mason/shoreinfo.comp
      13.6.3 Security with HTTP Authentication
         13.6.3.2 Restricting Access
            Apache Configuration Directives: chapter13/mason/httpd.conf
      13.6.4 Logging Web Activity
         Mason Component File: chapter13/mason/log.comp
      13.6.5 Creating and Using a Custom Perl Library
         Perl Library: chapter13/MyLib.pm
      13.6.6 Web-Based Overall Status and System Listing
         Example Configuration File: chapter13/status/status.conf
         Mason HTML File: chapter13/status/status.mhtml
         Mason Component File: chapter13/status/pinghost.comp
         Mason Component File: chapter13/status/checkport.comp
      13.6.7 Web Interface for System Configuration
         Example Configuration File: chapter13/config/config.conf
         Mason HTML File: chapter13/config/config.mhtml
         Mason HTML File: chapter13/config/submit.mhtml
      13.6.8 Executing Shell Commands on the Web
         13.6.8.1 Executing Local Commands
            Example Configuration File: chapter13/run/run.conf
            Mason HTML File: chapter13/run/run.mhtml
            Mason HTML File: chapter13/run/docmd.mhtml
         13.6.8.2 Executing Remote Commands
            13.6.8.2.1 Building a Remote Execution Daemon
               Example Configuration File: chapter13/remoted/remoted.conf
               Perl Script: chapter13/remoted/remoted.pl
            13.6.8.2.2 Building a Remote Execution Client
               Example Configuration File: chapter13/rrun/run.conf
               Mason HTML File: chapter13/rrun/run.mhtml
               Mason HTML File: chapter13/rrun/docmd.mhtml
               Mason Component File: chapter13/rrun/remote.comp

Appendix A: Introduction to Basic Tools
   A.1 The bash Shell
      A.1.2 Creating Simple bash Shell Scripts
         Bash Script: appendix_a/bash_example.sh
   A.2 Perl
      A.2.1 Basic Usage
         Perl Script: appendix_a/perl_example.pl

Appendix B: Customizing and Automating Red Hat Linux Installation
   A.1 Customizing Red Hat Linux (should have been B.1)
      B.1.2 Understanding the Red Hat Installation Data Files
         B.1.2.1 The comps File
            Example 'comps' File: appendix_b/example_comps
   A.2 Automating Red Hat Linux Installation with Kickstart (should have been B.2)
      B.2.1 Creating a Kickstart File
         B.2.1.1 Generalizing a Kickstart File      
            Example kickstart File: appendix_b/example.ks

Appendix C: Building RPMs
   C.3 Using an RPM Build Root
      Partial RPM SPEC File: appendix_c/build_root.spec
      Partial RPM SPEC File: appendix_c/build_root_GNU.spec
   C.6 More Advanced RPM Concepts
      C.6.4 Taking Action with RPM Triggers
         Partial RPM SPEC File: appendix_c/triggers
         RPM SPEC File (for test package): appendix_c/trigger_test.spec
      C.6.6 Relocatable RPM Packages
         Partial RPM SPEC File: appendix_c/relocation.spec
      C.6.7 RPM Subpackages
         Example RPM SPEC File: appendix_c/sub_packages.spec
   C.7 Automating Package Builds
      Example RPM SPEC File: appendix_c/auto_build.spec
      Bash Script: appendix_c/build.sh

