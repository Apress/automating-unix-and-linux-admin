#!/bin/bash
# Set this to the number of failed checks that can occur before 
# a restart should be attempted (usually one less than retry count)
failcount=2

# Store arguments
state="$1"
statetype="$2"
attempts="$3"
host="$4"

[ "$state" != "CRITICAL" ] && {
   # Exit if not in a critical state
   exit 0
}

if [ "$statetype" == "SOFT" ] ; then
   # Service has failed at least one test
   [ "$attempts" == "$failcount" ] && {
      ssh "root@$host" 'service httpd restart'
   }
else
   # Service has failed all status tests!
   # We should have restarted it before this happened.
   # We probably did, and it probably didn't fix the problem...
   # But, we can try one more time just for the fun of it.
   ssh "root@$host" 'service httpd restart'
fi

exit 0
