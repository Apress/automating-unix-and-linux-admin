#!/bin/bash

SLEEP=30   #seconds

while true ; do
   cat /usr/local/etc/services.conf | while read line ; do
      match=`echo "$line" | sed 's/|.*$//'`
      cmd=`echo "$line" | sed 's/^.*|//'`
      ps ax -o '%c %P' | awk -v "process=$match" \
         '{if (($1 == process) && ($2 == 1)) exit 1}' && {
         # Process not found!
         /usr/local/sbin/report ERROR "Process $match not running"
         [ -n "$cmd" ] && {
            $cmd && {
               /usr/local/sbin/report INFO \
                  "Process $match was restarted ($cmd)"
            }
         }
      }
   done
   sleep $SLEEP
done
