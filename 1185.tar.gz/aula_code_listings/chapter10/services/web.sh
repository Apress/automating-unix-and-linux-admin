#!/bin/bash

SLEEP=30    #seconds
TIMEOUT=10  #seconds
URL='http://localhost/index.html'
MATCH='<HTML>'

while true ; do
   wget -q -O - -T=$TIMEOUT --tries=1 "$URL" | grep -q "$MATCH" || {
      /usr/local/sbin/report ERROR "Web server not responding"
      /etc/rc.d/init.d/httpd restart && {
         /usr/local/sbin/report INFO "Web server restarted"
      }
   }
   sleep $SLEEP
done
