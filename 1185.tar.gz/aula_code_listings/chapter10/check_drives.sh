#!/bin/bash

types="ext2|ext3|ufs|vfat"
cutoff="90"

for drive in `mount | awk "/type ($types)/ {print \\\$1}"` ; do
   df "$drive" | awk -v "cutoff=$cutoff" '/^\// {
      gsub(/%$/, "", $5);
      if ($5 > cutoff) 
         print "Drive " $1 " (" $6 ") is " $5 "% Full"
      }'
done | /usr/local/sbin/report --stdin WARNING 'Drives almost full'
