#!/bin/bash

# Note, needs to be placed in /etc/log.d/scripts/services and named
# according to your configuration file (i.e. a config file of 
# 'example.conf' would require this file to be named 'example'.

# This is as nice script that will show you the lines you will
# be processing and reporting on.  It will first display the
# standard environment variables and then it takes STDIN and
# dump it right back out to STDOUT.

# These are the standard environment variables.
echo "Date Range: $LOGWATCH_DATE_RANGE"
echo "Detail Level: $LOGWATCH_DETAIL_LEVEL"
echo "Temp Dir: $LOGWATCH_TEMP_DIR"
echo "Debug Level: $LOGWATCH_DEBUG"

# Now take STDIN and dump it to STDOUT
cat

