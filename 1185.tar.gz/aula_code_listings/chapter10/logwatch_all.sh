#!/bin/bash

HOSTS='
   host1|admin1@someplace.com
   host2|admin2@someplace.com
   host3|admin3@someplace.com
'

for entry in $HOSTS ; do
   host=`echo "$entry" | sed 's/|.*$//'`
   email=`echo "$entry" | sed 's/^.*|//'`
   logwatch --mailto "$email" --hostname "$host"
done
