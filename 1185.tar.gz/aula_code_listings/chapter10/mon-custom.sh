#!/bin/bash

custom_check() {
   # Perform your custom check here
   # The host is passed in as $1
   # Return 0 on success, 1 on failure
   return 0
}

failed=''
for host in "$@" ; do
   custom_check "$host" || {
      failed="$failed $host"
   }
done

[ -n "$failed" ] && {
   echo "$failed"
   exit 1
}

exit 0

