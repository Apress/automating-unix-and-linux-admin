#!/bin/bash

URL="http://localhost/netsaint/index.html"
TIMEOUT=10 #(seconds)
MATCH="<HTML>"
restart="service httpd restart"

wget -q -O - -T=$TIMEOUT --tries=1 "$URL" | grep -q "$MATCH" || {
   # Something is wrong, so restart
   eval "$restart"
   exit $?
}

exit 0
