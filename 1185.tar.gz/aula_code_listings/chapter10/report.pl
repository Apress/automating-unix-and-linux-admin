#!/usr/bin/perl -w
use strict;

# Configuration items
my $MailThreshold = 'WARNING';
my $LogFile = '/var/log/event.log';
my $Email = 'alert@company.com';

# Available log levels
my %Levels = ( 
   'INFO'     => 1,
   'WARNING'  => 2,
   'ERROR'    => 3,
   'CRITICAL' => 4
);

sub usage () {
   print STDERR "Usage: $0 [--stdin] <level> <subject>\n";
   print STDERR "Levels: ";
   foreach (keys %Levels) {
      print STDERR "$_ ";
   }
   print STDERR "\n";
   exit 1;
}

# Check and store parameters
my $stdin = 0;
if ($ARGV[0] eq '--stdin') {
   shift @ARGV;
   $stdin = 1;
}
usage() unless ($#ARGV == 1);
usage() if ($ARGV[0] eq '--help');
my ($level, $subject) = @ARGV;
$level = uc($level);
usage() unless ($Levels{$level});

# Determine system's hostname (first portion only)
my $hostname = `hostname`;
chomp($hostname);
$hostname =~ s/\..*$//;
# Store formatted date string
my $date = localtime;

open (LOG, ">>$LogFile");
unless ($stdin) {
   if ($Levels{$level} >= $Levels{$MailThreshold}) {
      system ("mail -s '[$level] $hostname: $subject' '$Email'");
   }
   print LOG "$date $hostname [$level] $subject";
   close(LOG);
   exit 0;
}

my @lines;
while (my $line = <STDIN>) {
   push @lines, $line;
   print LOG "$date $hostname [$level] $subject: $line";
}
close(LOG);
if ((@lines) and $Levels{$level} >= $Levels{$MailThreshold}) {
   open (MAIL, "| mail -s '[$level] $hostname: $subject' '$Email'");
   foreach (@lines) {
      print MAIL $_;
   }
   close(MAIL);
}
exit 0;
