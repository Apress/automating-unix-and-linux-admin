#!/bin/bash

# This file should have one host per line
host_list="/usr/local/etc/all_hosts"

# This is the script that configures each host
configure_system="/usr/local/sbin/configure_system.sh"

# Process each host
success_count=0
failure_count=0
failure_list=''
for host in `cat $host_list` ; do
   echo
   if $configure_system "$host" ; then
      echo "   Host $host Configuration Successful!"
      success_count="$[$success_count+1]"
   else
      echo "   Host $host Configuration FAILED!"
      failure_count="$[$failure_count+1]"
      failure_list="$failure_list $host"
   fi
done

# Display summary
echo
echo "Total of $[$success_count+$failure_count] systems processed:"
echo "   $success_count Success(es)"
echo "   $failure_count Failure(s)"
echo
[ -n "$failure_list" ] && {
   echo "$failure_count host(s) failed:"
   for host in $failure_list ; do
      echo "   $host"
   done
   exit 1
}
exit 0
