#!/bin/bash

# The base directory
host_dir='/usr/local/etc/hosts'
base_dir='/usr/local/etc/sysconfig'
source '/usr/local/sbin/configure.functions'

# Specify any necessary options for ssh here
alias ssh="/usr/bin/ssh"

[ $# -lt 1 ] && die "Usage: $0 host"
host="$1"
echo "Configuring host $host:"

# We need a safe local and remote temp file
localtemp=`mktemp /tmp/sysconfig-XXXXXX` || 
   die "Could not create local temp file"
remotetemp=`ssh $host 'mktemp /tmp/sysconfig-XXXXXX'` || 
   die "Could not create remote temp file"

# First, retrieve group list for the host
cd "$host_dir" || die "Host directory $host_dir not found"
groups="$(grep -l "^$host$" *)"

# Read settings for this host
read_conf "$base_dir/conf/all" 
for group in $groups ; do
   read_conf "$base_dir/conf/groups/$group" 
done
read_conf "$base_dir/conf/systems/$host" 

# Now, push out any necessary files
for dir in all $groups ; do
   for file in "$base_dir/files/$dir/"* ; do
      if [ -f "$file" ] ; then
         push_file "$file" "$host"
      fi
   done
done

# Next, push out any necessary templates
for dir in all $groups ; do
   for file in "$base_dir/templates/$dir/"* ; do
      if [ -f "$file" ] ; then
         do_template "$file" "$localtemp"
         push_file "$localtemp" "$host"
      fi
   done
done

# Finally, execute any necessary scripts
for dir in all $groups ; do
   for file in "$base_dir/scripts/$dir/"* ; do
      if [ -f "$file" ] ; then
         push_file "$file" "$host" "$remotetemp"
         ssh "root@$host" "chmod u+x $remotetemp ; $remotetemp" || 
            die "Execution of script $(basename "$file") failed"
         echo "   Executed Script: $(basename "$file")"
      fi
   done
done

# Clean up
rm -f "$localtemp"
ssh "root@$host" "rm -f $remotetemp"

exit 0
