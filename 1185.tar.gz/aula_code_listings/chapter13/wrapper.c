#include <stdio.h>

#define WEB_UID 99

int main (int argc, char *argv[]) {
   char *command[5];
   char *basename;

   // Make sure this user is authorized
   if (getuid() != WEB_UID) {
      fprintf(stderr, "You are not authorized.\n");
      return 1;
   }

   // Initialize command items with NULLs
   memset(command, 0, sizeof(command));

   // Determine the basename for this program
   if ((basename = strrchr(argv[0], '/'))) {
      // Basename starts after the last forward-slash in path
      basename++;
   } else {
      basename=argv[0];
   }

   // Using the basename, decide which command to execute
   if (!strcmp(basename, "reboot")) {
      command[0] = "/sbin/reboot";
   } else if (!strcmp(basename, "restart_dhcpd")) {
      command[0] = "/etc/rc.d/init.d/dhcpd";
      command[1] = "restart";
   } else {
      fprintf(stderr, "%s: Unknown invocation.\n", basename);
      return 1;
   }

   // Execute command as root
   setuid(geteuid());
   setgid(getegid());
   execv(command[0], command);
   return 0;
}

