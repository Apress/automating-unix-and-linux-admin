#!/bin/bash

usage() {
   echo "Usage: $0 [username] [full name]" 2>/dev/null
   exit 99;
}
[ "$1" == "--help" ] && usage
new_user="$1"
full_name="$2"

[ -n "$new_user" ] || {
   echo -n "Enter username to add: " >&2
   read new_user
}

[ -n "$full_name" ] || {
   echo -n "Enter full name: " >&2
   read full_name
}

# ... create user ...

echo "New account successfully created!" >&2
echo "New UserID: $new_uid"

