#!/bin/bash

FILE='/usr/local/etc/mainmenu.conf'

get_value() {
   echo "$1" | sed "s/.*|$2=\([^|]*\).*/\1/"
}

IFS='
'
select resp in \
   `cat "$FILE" | while read line ; do
       get_value "$line" item
    done`
do
   # Check for q or Q to exit
   case "$REPLY" in
      [qQ])
         break
         ;;
   esac
   # Execute command
   cat "$FILE" | while read line ; do
      [ `get_value "$line" item` == "$resp" ] && {
         eval `get_value "$line" cmd`
      }
   done
done

