#!/usr/bin/perl -w
use strict;

use lib '/usr/local/www/lib';
use MyLib;
use IO::Socket;
use IO::Handle;

my $Port = 10000;
my $cmds = MyLib::read_file('/usr/local/etc/remoted.conf');

my $server = IO::Socket::INET->new(
   LocalPort => $Port,
   Type => SOCK_STREAM,
   Reuse => 1,
   Listen => 10 ) or die "Couldn't bind on port $Port: $@\n";

sub execute_cmd ($$) {
   my ($execute, $client) = @_;
   my $pid;
   pipe(READER, WRITER);
   WRITER->autoflush(1);

   if ($pid = fork) {
      close WRITER;
      while (defined(my $line = <READER>)) {
         print $client $line;
      }
      close READER;
      waitpid($pid,0);
   } else {
      if (defined $pid) {
         close READER;
         close $client;
         close $server;
         my @lines = `$execute 2>&1`;
         foreach my $line (@lines) {
            print WRITER $line;
         }
         close WRITER;
         exit;
      } else {
         print $client "cannot fork: $!" unless defined $pid;
      }
   }
}

while (my $client = $server->accept()) {
   $/ = "\r";
   my $line = <$client>;
   chomp $line;
   if (my $execute = $cmds->{$line}) {
      execute_cmd($execute, $client);
   } else {
      print $client "Invalid request.\n";
   }
   close ($client);
}
