
# $1 is the value entered by the user
# $2 is the expected datatype 
check_data_type() {
   case $2 in
      integer)
         echo "$1" | egrep -q '^[0123456789]+$'
         ;;
      network_address)
         echo "$1" | \
            egrep -q \
               '^[0123456789]{1,3}\.[0123456789]{1,3}\.
               [0123456789]{1,3}\.[0123456789]{1,3}$' 
         ;;
      directory)
         test -d "$1"
         ;;
      file)
         test -f "$1"
         ;;
      *)
         # Unsupported datatype, return true
         true
         ;;
   esac
   return $?
}

check_value() {
   var="$(get_value "$1" var)"
   default="$(get_value "$1" default)"
   case "$2" in
      *"'"*)
         echo " ** Single quotes (') are not allowed! **"
         ;;
      '')
         if eval [ -z "\"\${$var:-$default}\"" ]; then
            echo " ** Please enter a value (no default available) **"
         else
            eval echo "$var=\"'\${$var:-$default}'\"" >&2
            return 0
         fi
         ;;
      *)
         if check_data_type "$2" "$(get_value "$1" datatype)" ; then
            echo "$var='$2'" >&2
            return 0
         else
            echo " ** Invalid value entered! **"
         fi
         ;;
   esac
   return 1
}
