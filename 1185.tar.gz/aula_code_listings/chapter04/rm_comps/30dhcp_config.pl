#!/usr/bin/perl -w
use strict;
my $dhcpd_conf = '/usr/local/etc/dhcpd.conf';
my $host = "$ENV{'old_hostname'}";

# Open up the input and output files
open(IN, "$dhcpd_conf") or die "Could not open $dhcpd_conf: $!\n";
open(OUT, ">$dhcpd_conf.new") or 
   die "Could not open $dhcpd_conf.new: $!\n";

# Now, go through the file, looking for deleted host
my $line;
LOOP: while ($line = <IN>) {
   if ($line =~ /host\s+$host\s+{/) {
      # Found the host we are removing
      while ($line = <IN>) {
         # Loop through file until closing brace found
         # near beginning of line
         next LOOP if ($line =~ /^\s+}/);
      }
   }
   # Print other lines out
   print OUT $line;
}
close(IN);
close(OUT);

# Copy the new file over the original
unless (rename("$dhcpd_conf.new", $dhcpd_conf)) {
   die "Could not replace $dhcpd_conf: $!\n";
}

# Indicate success on STDOUT
print "true;\n";
exit 0
