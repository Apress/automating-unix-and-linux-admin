#!/bin/bash

available_list="$data_dir/available"
allocated_list="$data_dir/allocated"

# We must find the IP address for other removal components
[ -w "$allocated_list" ] && {
   ip_address=`cat "$allocated_list" | sed -n \
      "s/^\([0-9][0-9.]*\) $old_hostname$/\1/p"`
   
   # Now, remove this IP from the allocated list
   egrep -v "^[0-9.]+ $old_hostname$" \
      "$allocated_list" > "$allocated_list.new" && \
         mv "$allocated_list.new" "$allocated_list"
}

# And add the IP back to the available list
echo "$ip_address" >> "$available_list"

# Finally, return the IP, and return true
echo "export ip_address=$ip_address;"
echo "true;"
