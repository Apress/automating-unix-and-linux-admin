#!/bin/bash

echo -n "Enter the system's MAC address (no colons!): " >&2
read mac_address

# First, convert all letters to lowercase in $mac_address
mac_address="$(echo $mac_address | tr 'A-Z' 'a-z')"

# Next, make sure it contains exactly 12 valid characters
if ! echo "$mac_address" | egrep -q '[0-9a-f]{12}' ; then
   echo "Invalid MAC address: $mac_address!" >&2
   echo "false;"
   exit 1
fi

# Finally, insert colons within the MAC address
mac_address="$(echo $mac_address | sed \
   's/\(..\)\(..\)\(..\)\(..\)\(..\)\(..\)/\1:\2:\3:\4:\5:\6/')"

# Make sure the MAC address has not already been specified
if grep -q "^$mac_address " "$data_dir/macs" ; then
   echo "MAC address already exists: $mac_address" >&2
   echo "false;"
   exit 1
fi

# Record new hostname
echo "$mac_address $new_hostname" >> "$data_dir/macs"

echo "export mac_address=$mac_address;"
echo "true;"
exit 0
