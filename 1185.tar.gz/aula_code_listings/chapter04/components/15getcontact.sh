#!/bin/bash

echo -n "Enter the system's contact: " >&2
read contact

# Record the contact
echo "$new_hostname $mac_address $contact" >> "$data_dir/contacts"
echo

echo "export contact=$contact;"
echo "true;"
exit 0
