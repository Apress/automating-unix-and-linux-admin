#!/bin/bash

available_list="$data_dir/available"
allocated_list="$data_dir/allocated"

[ -s $available_list ] || {
   # File is empty or non-existent, return false
   echo "No IP Addresses Available ($available_list is empty!)" >&2
   echo "false;"
   exit 1
}

# Pick the first IP address from the available list
ip_address="$(head -n1 $available_list)"

# In addition, write the new available list
tail +2 "$available_list" > "$available_list.new" && \
   mv "$available_list.new" "$available_list"

# Now, log the new allocation
echo "$ip_address $new_hostname" >> "$allocated_list"

# Display the IP address to the user
echo "IP Address Allocated: $ip_address" >&2

# Finally, return the IP, and return true
echo "export ip_address=$ip_address;"
echo "true;"
