#!/bin/bash

# Local directory containing files to be transferred
file_dir='/usr/local/lib/sys_prep_files'

# Assumes .shosts is configured on new system
alias rsh="/usr/bin/ssh -1 -o 'UsePrivilegedPort yes'"
alias rcp="/usr/bin/scp -1 -o 'UsePrivilegedPort yes'"

die() {
   echo >&2
   for i in "$@" ; do
      echo "$i" >&2
   done
   echo >&2
   exit 99
}

echo ' ** New System Preparation ** '
echo
echo -n "Enter new system's hostname: "
read -e HOST

echo "Checking hostname: $HOST"
RESULT=`ping -w2 $HOST 2>&1`
if [ $? -ne 0 ] ; then
   if echo $RESULT | grep -q 'unknown host' ; then
      die 'Host does not exist (no DNS entry)'
   fi
   IPADDR=`host "$HOST" | sed 's/^.* \([0-9.]*\)$/\1/'`
   die 'Host not responding... is the correct IP configured?' \
      "The registered IP address for $HOST is $IPADDR"
fi

# Create new directories (if necessary)
rsh -l root $HOST 'mkdir -p ~/.ssh ~/setup' || \
   die 'Could not create ~/.ssh and ~/setup dirs'

# Copy files
cd $file_dir 2>/dev/null || die "Directory $file_dir not found!"
rcp ssh_public_key root@$HOST:~/.ssh/authorized_keys || \
   die 'Could not create authorized keys file'
rcp *.rpm sysadmin_crontab initial_setup.sh \
   root@$HOST:~/setup || die 'Could not transfer files'

# Make sure permissions on .ssh and contents are correct
rsh -l root $HOST 'chmod og-rwx ~ ~/.ssh ~/.ssh/*' || \
   die 'Could not set permissions on .ssh directory'

# Install any RPMs that were copied over
rsh -l root $HOST 'rpm -Uvh ~/setup/*.rpm' || \
   die 'Failed to install RPMs'

# Now, run initial setup script
rsh -l root $HOST 'bash ~/setup/initial_setup.sh' ||
   die 'Execution of initial_setup script failed!'

echo "Host $HOST Configuration Complete"
exit 0
