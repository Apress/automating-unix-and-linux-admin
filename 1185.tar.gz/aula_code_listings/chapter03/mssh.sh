#!/bin/bash

# This file should have one host per line
host_list='/usr/local/etc/all_hosts'

# Check for required argument
[ $# -gt 0 ] || {
   echo "usage: $0 command ..." >&2
   exit 1
}

# Execute the command(s) on each host
for host in `cat "$host_list"` ; do
   echo "  ** $host **"
   ssh "$host" "$@" || {
      echo "ERROR: Could not execute $* on $host!" >&2
   }
done
