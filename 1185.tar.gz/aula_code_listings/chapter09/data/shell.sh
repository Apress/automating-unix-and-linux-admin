#!/bin/bash

onlyaction 'adduser'

echo "Select a shell:" >&2
select shell in `sort $shell_file` ; do
   [ -n "$shell" ] && break
done

echo >&2
echo "shell='$shell';"
echo 'true;'
exit 0
