#!/bin/bash

onlyaction 'adduser'

export PS3="Enter group ('q' to quit): "
extragroups=''
[ -n "$optional_groups" ] && {
   echo "Select one or more extra groups:" >&2
   select group in $optional_groups ; do
      [ -z "$group" ] && break
      extragroups="$extragroups $group"
   done
}

echo >&2
echo "extragroups='$extragroups $default_groups';"
echo 'true;'
exit 0
