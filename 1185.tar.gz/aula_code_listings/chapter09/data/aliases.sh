#!/bin/bash

onlyaction 'adduser'

aliases=''
echo >&2
while true ; do
   echo -n "Enter mail alias [leave blank when done]: " >&2
   read -e value
   if [ -n "$value" ] ; then
      aliases="$aliases $value"
   else
      echo >&2
      break
   fi
done
echo >&2

echo "aliases='$aliases';"
echo 'true;'
exit 0
