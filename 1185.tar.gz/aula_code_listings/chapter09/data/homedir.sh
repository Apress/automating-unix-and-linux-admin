#!/bin/bash

if [ "$action" == "deluser" ] ; then
   echo "homedir='$(eval echo ~$username)';"
   echo 'true;'
   exit 0
fi

dirlist=''
if [ "$show_space" == "1" ] ; then
   # Determine available space on each drive
   for entry in $home_dirs ; do
      space=`
         if echo "$entry" | grep -q ':' ; then
            host=$(echo "$entry" | sed 's/:.*$//')
            dir=$(echo "$entry" | sed 's/^.*://')
            if [ "$use_ssh" == "1" ] ; then
               if ! ssh -T $host "df -m $dir" ; then
                  echo "WARNING: Could not access $dir on $host" >&2
               fi
            else
               if ! mount -t nfs "$host:$dir" /mnt/tmp ; then
                  echo "WARNING: Could not mount $dir from $host" >&2
               fi
               df -m /mnt/tmp
               umount /mnt/tmp
            fi 
         else
            # Local directory
            df -m $entry
         fi 2>/dev/null | awk '/^\// {print $4}'
      `
      [ -z "$space" ] && {
         space='??'
      }
      if [ -z "$dirlist" ] ; then
         dirlist="$entry ($space MB avail)"
      else
         dirlist="$dirlist|$entry ($space MB avail)"
      fi
   done
else
   # Just display the drives
   dirlist=`echo "$home_dirs" | sed 's/ /|/g'`
fi

homedir=''
IFS="|"
while [ -z "$homedir" ] ; do
   select homedir in $dirlist ; do
      if [ -n "$homedir" ] ; then
         homedir=`echo "$homedir" | sed 's/ (.*$//'`
         break
      fi
   done
done
unset IFS

echo >&2
echo "homedir='$homedir';"
echo 'true;'
exit 0
