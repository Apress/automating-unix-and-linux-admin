#!/usr/bin/perl -w
use strict;

# Only need to allocate a UID/GID if adding a new user
if ($ENV{'action'} ne 'adduser') {
   print "true;";
   exit 0;
}

my @IDs;
my @files = ( 
   $ENV{'passwd_file'},
   $ENV{'yp_passwd_file'},
   $ENV{'group_file'},
   $ENV{'yp_group_file'}
);

foreach my $file (@files) {
   next unless $file;
   unless (open (FILE, $file)) {
      print STDERR "Can't open $file: $!\n";
      print "false;\n";
      exit 1;
   }
   while (my $line = <FILE>) {
      if ($line =~ (/^[^:]+:[^:]*:(\d+):/)) {
         $IDs[$1] = 1;
      }
   }
   close (FILE);
}

for (my $i = $ENV{'min_uid'}; $i <= $ENV{'max_uid'}; $i++) {
   if ($IDs[$i]) {
      print STDERR "\nAllocated UID/GID: $i\n\n";
      print "newid=$i;";
      print "true;";
      exit 0;
   }
}

print STDERR 
   "Out of UIDs (min=$ENV{'min_uid'}, max=$ENV{'max_uid'})\n";
print "false;";
exit 1;
