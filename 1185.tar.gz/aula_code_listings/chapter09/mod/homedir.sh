#!/bin/bash

if echo "$homedir" | grep -q ':' ; then
   host=$(echo "$homedir" | sed 's/:.*$//')
   dir=$(echo "$homedir" | sed 's/^.*://')
   if [ "$use_ssh" == "1" ] ; then
      if [ "$action" == "deluser" ] ; then
         ssh -T $host "mv $dir/$username $dir/deleted-$username"
      else
         ssh -T $host "cp -r $skel_dir $dir/$username" && \
         ssh -T $host "chown -R $username.$username $dir/$username" \
            || die "Could not create $dir on $host via SSH"
      fi
   else
      if ! mount -t nfs "$host:$dir" /mnt/tmp ; then
         die "Could not mount $dir from $host"
      fi
      if [ "$action" == "deluser" ] ; then
         mv /mnt/tmp/$username /mnt/tmp/deleted-$username
      else
         cp -r "$skel_dir" "/mnt/tmp/$username" && \
         chown -R $username.$username "/mnt/tmp/$username" || \
            die "Could not create home directory in $dir on $host"
      fi
      umount /mnt/tmp
   fi 
else
   # Local directory
   if [ "$action" == "deluser" ] ; then
      mv $homedir/$username $homedir/deleted-$username
   else
      cp -r $skel_dir $homedir/$username && \
      chown -R $username.$username $homedir/$username || \
         die "Could not create home directory in $homedir"
   fi
fi

exit 0
