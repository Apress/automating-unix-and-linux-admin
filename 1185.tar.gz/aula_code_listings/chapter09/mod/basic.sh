#!/bin/bash

# Determine which password & group files
pwfile="$yp_passwd_file"
[ -z "$pwfile" ] && {
   pwfile="$passwd_file"
}
gfile="$yp_group_file"
[ -z "$gfile" ] && {
   gfile="$group_file"
}

if [ "$action" == "deluser" ] ; then

   echo "Removing entry from $pwfile..."
   remove_line "^$username:" "$pwfile"

   echo "Removing entry from $gfile..."
   remove_line "^$username:" "$gfile"

   [ -n "$shadow_file" ] && {
      echo "Removing entry from $shadow_file..."
      remove_line "^$username:" "$shadow_file"
   }

else

   # Determine home directory (either automounted or not)
   if [ -z "$automount_dir" ] ; then
      home="$automount_dir/$username"
   else
      home="$homedir"
   fi

   echo "Creating entry in $pwfile..."
   echo "$username:*:$newid:$newid:$fullname:$home:$shell" \
      >> $pwfile

   echo "Creating entry in $gfile..."
   echo "$username:*:$newid:$username" >> $gfile

   # Create shadow entry, if applicable
   [ -n "$shadow_file" ] && {
      # Creation of the shadow entry is OS-dependent
      echo "Creating entry in $shadow_file..."
      echo "$username:*::::::" >> $shadow_file
   }

fi

exit 0
