#!/bin/bash

if [ -n "$yp_passwd_file" ] ; then
   cd /var/yp
   make
fi

