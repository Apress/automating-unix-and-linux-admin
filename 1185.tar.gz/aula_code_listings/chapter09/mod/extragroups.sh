#!/bin/bash

# Determine group file
gfile="$yp_group_file"
[ -z "$gfile" ] && {
   gfile="$group_file"
}

if [ "$action" == "deluser" ] ; then
   echo "Removing $username from all groups"
   cp -p "$gfile" "$gfile.new"
   sed -e "s/:$username,/:/" \
       -e "s/:$username$/:/" \
       -e "s/,$username//" \
       "$gfile" > "$gfile.new" && \
          mv "$gfile.new" "$gfile"

else

   [ -n "$extragroups" ] && {
      for group in $extragroups ; do
         if grep -q "^$group:" "$gfile" ; then
            echo "Adding $username to group $group"
            cp -p "$gfile" "$gfile.new"
            if sed -e "s/^$group:.*[^:]$/&,$username/" \
                   -e "s/^$group:.*:$/&$username/" \
                   "$gfile" > "$gfile.new" ; then
               mv "$gfile.new" "$gfile"
            else
               die "Could not add $username to group $group"
            fi
         else
            # Doesn't exist yet, find ID and create entry
            echo "Creating new group $group for $username"
            eval `$component_dir/data/getuid.pl` || \
               die "Could not allocate ID for new group $group"
            echo "$group:*:$newid:$username" >> $gfile
         fi
      done
   }

fi

exit 0
