#!/bin/bash

dohost() {
   if echo "$1" | grep -q ':' ; then
      host=$(echo "$1" | sed 's/:.*$//')
      if [ "$use_ssh" == "1" ] ; then
         ssh -T $host "bash -"
      else
         dir=$(echo "$hostdir" | sed 's/^.*://')
         if ! mount -t nfs "$host:$dir" /mnt/tmp ; then
            die "Could not mount $dir from $host"
         fi
         bash -
         umount /mnt/tmp
      fi 
   else
      bash -
   fi
}

source /usr/local/etc/usertool.conf

for hostdir in $home_dirs ; do
   dir=$(echo "$hostdir" | sed 's/^.*://')
   if [ "$use_ssh" != "1" ] ; then
      dir="/mnt/tmp"
   fi
   echo "Checking $hostdir..."
   dohost $hostdir << __EOF__

for entry in `find $dir -type d -name 'deleted-*' -mtime +30 -print`
do 
   rm -rf \$entry; 
done

__EOF__
done

exit 0
