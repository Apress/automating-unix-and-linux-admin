#!/bin/bash

TMPDIR=~/tmp
WARNTIME=30
RMTIME=60
SIZE="500k"
USERS=`awk -F: '{if ($3 >= 500) print $1}' /etc/passwd`

# Find files to warn about
for user in $USERS ; do
   homedir=`eval echo ~$user`
   find $homedir -atime +$WARNTIME -type f -size $SIZE -print \
      > $TMPDIR/$user
   [ -s "$TMPDIR/$user" ] && {
      # Some files were found
      mail -s 'SCHEDULED FOR DELETION!!' "$user" < "$TMPDIR/$user"
   }
   rm -f "$TMPDIR/$user"
done

# Now, delete any files that are old enough
find $homedir -atime +$RMTIME -type f -size $SIZE -exec rm -f {} \;
