#!/bin/bash

mkdir -p /etc/new_files
cd /etc/new_files

for file in hosts resolv.conf nsswitch.conf ; do
   if lftpget "http://server.mydomain.com/$file" ; then
      if [ -s "$file" ] ; then
         cat "$file" > "/etc/$file"
      fi
   fi
done

rm -rf /etc/new_files

