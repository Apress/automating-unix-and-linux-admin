#!/bin/bash

# First, determine our system type
host_type=`uname`

# Now, isolate our fileserver with sed and remove the beginning of the line
source=`sed -n "s/^$host_type //p" /usr/local/etc/fileservers`

# Make sure a valid remote filesystem was found (would contain a colon)
echo "$source" | grep -q ':' && {
   # Finally, transfer the files
   rsync -a --delete $source/ /usr/local/
}

